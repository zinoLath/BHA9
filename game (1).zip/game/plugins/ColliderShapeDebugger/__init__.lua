-- Collider Shape Debugger

lstg.plugin.RegisterEvent("afterTHlib", "Collider Shape Debugger", 0, function()
    lstg.DoFile("ColliCheck.lua")
end)
