This is where you put your Lua scripts.

Any folder or zip file found in this folder that has a file named `root.lua`
at its base will be treated as a launchable game script.