local M = {}
local diff_manager = M

function diff_manager:initialize()
    
    
end

return M