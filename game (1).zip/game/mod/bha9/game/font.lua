local M = {}
local yabmfr = require("yabmfr")
M.hadirsans = yabmfr.LoadFont("assets/menu/hhadirsans.fnt")

return M