# THlib for LuaSTG Evo + RyannLib

## Directions:
1. Download or clone this repository. Unzip it if you have to.
2. [Download the latest LuaSTG Evo for your platform.](https://github.com/KaleiAlma/LuaSTG-Evo/releases)
3. Place LuaSTG Evo in the folder you downloaded at step 1.

Ryannlib: https://ryann1908.itch.io/ryannlib