-- 全局配置信息

---@class gconfig
gconfig = {}

gconfig.bundle_version = "0.8.22"

gconfig.bundle_name = "LuaSTG aex+"

gconfig.window_title = gconfig.bundle_name .. " v" .. gconfig.bundle_version
