local M = {}
local function dot(a,b)
    return a.x*b.x+a.y*b.y
end
local function cross(a,b)
    return a.x*b.y-a.y*b.x
end

require("math.additions")
---@~english Collision check for circle and parameter. Uses Cocos2D positions for operations. Code by Texel (Texel#4217)
---@param circP lstg.Vector2 Circle's position
---@param circR number Circle's radius
---@param capA lstg.Vector2 Capsule's location A
---@param capB lstg.Vector2 Capsule's location B
---@param capR number Capsule's radius
---@return boolean True if it's colliding.
function M:CircleToCapsule(circP, circR, capA, capB, capR)
    local effWidth = circR + capR; -- Compute total radius
    local effA, effB = circP - capA, circP - capB; -- Shift line segment coordinate system
    local h = math.clamp( dot(effA,effB) / dot(effB,effB) , 0, 1); -- Distance along line segment that we are closet too
    --print(effA,effB,h)
    return (circP - (effB * h )):Length() <= effWidth; -- Check if the distance to our closet point on line to the circle point is within the combined radius
end


return M