--satori_player = require("zinolib.player.satori")

--require("zinolib.player.rumia.rumia")
--AddPlayerToPlayerList('Satori Komeiji','rumia_player','Satori')