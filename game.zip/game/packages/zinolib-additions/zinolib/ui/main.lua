local M = Class()
local ui = M

function ui:init()
    self.layer = LAYER_UI
    self.group = GROUP_GHOST
end


return M