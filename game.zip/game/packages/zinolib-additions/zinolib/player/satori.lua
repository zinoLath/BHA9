local M = Class(player_class)
local satori_player = M
LoadTexture('marisa_player','zinolib/player/marisa.png')
LoadImageGroup('marisa_player','marisa_player',0,0,32,48,8,3,1,1)
LoadImage('marisa_support','marisa_player',144,144,16,16)
function satori_player:init()
	player_class.init(self)
    
    self.name = "Satori"
    self.imgs={}
    self.A = 1 self.B = 1
    for i=1,24 do self.imgs[i]='marisa_player'..i end

    self.stats = {
        card_rate = 1,
        speed = 1,
        damage = 1,
        shot_damage = 1,
        spell_damage = 1,
        item_damage = 1,
        spell_rate = 1,
        shot_rate = 1,
    }
    self.base_speed = {4.5, 2}
    self.modifiers = {}
	self.slist=
	{
		{            nil,          nil,              nil,            nil},
		{{  0,32,  0,29},          nil,              nil,            nil},
		{{-30,10, -8,23},{30,10, 8,23},              nil,            nil},
		{{-30,0,-10,24},{   0,32,   0,32},{30,0,10,24},            nil},
		{{-30,10,-15,20},{-12,32,-7.5,29},{12,32,7.5,29},{30,10,15,20}},
		{{-30,10,-15,20},{-7.5,32,-7.5,29},{7.5,32,7.5,29},{30,10,15,20}},
	}
end
function satori_player:add_modifier(priority, name, func)
    table.insert(self.modifiers, {priority = priority, name = name, func = func})
end
function satori_player:remove_modifier(name)
    for k, mod in self.modifiers do
        if mod.name == name then
            table.remove(self.modifiers, k)
            return
        end
    end
end
local function priosort(mod1, mod2)
    return mod1.priority < mod2.priority
end

function satori_player:frame() 
	player_class.frame(self)
    for k,v in pairs(self.stats) do
        self.stats[k] = 1
    end
    table.sort(self.modifiers,priosort)
    for k, mod in self.modifiers do
        mod.func(self.stats)
    end
    self.hspeed = self.base_speed[1] * self.stats.speed
    self.lspeed = self.base_speed[2]
end

function satori_player:shoot()
	PlaySound('plst00',0.3,self.x/1024)
	self.nextshoot=4
end

function satori_player:spell()

end

function satori_player:render()
	for i=1,4 do
		if self.sp[i] and self.sp[i][3]>0.5 then
			Render('marisa_support',self.supportx+self.sp[i][1],self.supporty+self.sp[i][2],self.timer*3)
		end
	end
	player_class.render(self)
end

return M