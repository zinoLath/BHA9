local M = Class()
local menu = M
local namedtask = require("zinolib.namedtask")

function menu:init()
    self.coroutine = coroutine.create(self.class.co_update)
    self.first_selectable = nil
    self.curr_select = self.first_selectable
end

function menu:frame()
    namedtask.Do(self)
end

function menu:co_update() --this is the coroutine function that should be updating everything (it's better to use a coroutine with a while true tbh)

end

function menu:update()
    local C, E = coroutine.resume(self.coroutine,self)
    if(not C)then
        error(E)
    end
end

function menu:move_in() --both of these are coroutines!!

end

function menu:move_out()

end

return M