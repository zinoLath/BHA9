local M = Class()
local manager = require("zinolib.card.manager")
local card = M
card.id = "DEFAULT_CARD"
card.img = "img_void"
card.name = "DEFAULT CARD"
card.description = "DEFAULT CARD DESCRIPTION"
card.cost = 1
card.discard = false
card.type = manager.TYPE_SKILL

function card:init(is_focus)
    if is_focus == nil then
        is_focus = player.slow
    end
    self.group = GROUP_GHOST
    self.context = {
        is_focus = is_focus,
        lvl = 1
    }
    lstg.var.card_context.cards[self.class.id] = self.context
    self.class.get(self)
    if player.cards == nil then
        player.cards = {}
    end
    table.insert(player.cards,self)
end
function card:kill()
    self.class.throw(self)
end

function card:get()

end

function card:lvlup()

end

function card:frame()
    task.Do(self)
end

function card:circle()

end

function card:throw()

end

return M