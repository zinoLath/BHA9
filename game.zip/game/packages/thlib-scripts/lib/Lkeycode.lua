
KEY = lstg.Input.Keyboard

return KEY
