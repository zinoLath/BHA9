-- THlib

lstg.plugin.LoadPlugins()
lstg.plugin.DispatchEvent("beforeTHlib")
Include("THlib/THlib.lua")
Include("load.lua")
lstg.plugin.DispatchEvent("afterTHlib")
